def myfunc():
    print("in myfunc()")


def echo(event):
    print(event)
    return event


def double(event):
    return event * 2


def add3(event):
    return event + 3
